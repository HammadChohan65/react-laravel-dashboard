import React,{useEffect} from 'react'
import {useNavigate} from 'react-router-dom'

function Protected(props){
    const navigator = useNavigate();
    useEffect(()=>{
        if(!localStorage.getItem('user-info') || (localStorage.getItem('user-info')).error != '' ){
            navigator('/login')
        }
    },[])
    let Comp = props.comp;
    return(
        <Comp/>
    );
}
export default Protected