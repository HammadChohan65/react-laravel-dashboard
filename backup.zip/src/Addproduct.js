import React from 'react';
import Header from './Header'

function Addproduct(){
    return(
        <>
        <Header/>
        <h1>Addproduct Page</h1>
        </>
    );
}

export default Addproduct