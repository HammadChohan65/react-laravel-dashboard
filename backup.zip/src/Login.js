import React,{useState,useEffect} from 'react';
import {useNavigate} from 'react-router-dom'
import Header from './Header'
function Login(){

    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
    const navigator = useNavigate ();  
    useEffect(()=>{
        if(localStorage.getItem('user-info')){
            if(localStorage.getItem('user-info').error != ''){
                  alert('Email/Password Is Incorrect')  
            }else{
                setTimeout(()=>{
                    alert('Loged in Successfully')     
                },1000)
                navigator('/add')
            }
        }
    },[])

    async function Login(){
        let data = {email,password}
        let result = await fetch('http://localhost:8000/api/login',{
            method:'POST',
            headers:{
                'Content-Type':'application/json',
                'Accept':'application/json'
            },
            body:JSON.stringify(data)
        })
        result = await result.json();
        // save in local storage
        localStorage.setItem('user-info',JSON.stringify(result))
        navigator('/add')   

    }
    return(
        <>
        <Header/>
        
        <div className='col-sm-6 offset-3'>
        <h1>User Login</h1>
        <input type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} className='form-control' placeholder='email' /><br/>
        <input type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}} className='form-control' placeholder='password' /><br/><br/>
        <button onClick={Login} className='btn btn-primary'>Login</button>
        </div>

        </>
    );
}

export default Login