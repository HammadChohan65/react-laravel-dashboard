import React from 'react';
import Header from './Header';
function Updateproduct(){
    return(
        <>
        <Header/>
        <h1>Updateproduct Page</h1>
        </>
    );
}

export default Updateproduct